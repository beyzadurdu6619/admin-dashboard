package com.example.lap9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
