import 'package:flutter/cupertino.dart';

class urunGosterim extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {

    throw UnimplementedError();
  }

}