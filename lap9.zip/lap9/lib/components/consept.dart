import 'package:flutter/animation.dart';
import 'package:flutter/material.dart';

const Color Kpraimry = const Color(0xfff57578);
const double paddingg = 20.0;

